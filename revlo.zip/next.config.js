// next.config.js (for Next.js 14)
/** @type {import('next').NextConfig} */
const nextConfig = {
  // Add your config options here
};

module.exports = nextConfig;
