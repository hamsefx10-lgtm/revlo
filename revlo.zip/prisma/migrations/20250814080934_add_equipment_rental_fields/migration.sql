-- AlterTable
ALTER TABLE "expenses" ADD COLUMN     "equipmentName" TEXT,
ADD COLUMN     "rentalCost" DECIMAL(12,2),
ADD COLUMN     "rentalPeriod" TEXT;
