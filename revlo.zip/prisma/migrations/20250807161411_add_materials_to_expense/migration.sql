-- AlterTable
ALTER TABLE "expenses" ADD COLUMN     "materials" JSONB;
