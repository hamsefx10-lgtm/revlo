-- AlterTable
ALTER TABLE "expenses" ADD COLUMN     "transportType" TEXT;
