import { getServerSession } from 'next-auth/next';
import type { Session } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { NextResponse } from 'next/server';

export async function getSessionCompanyId(): Promise<string> {
  const session = await getServerSession(authOptions) as Session | null;
  
  if (!session?.user?.companyId) {
    throw new Error('Unauthorized: No company ID found in session');
  }
  
  return session.user.companyId;
}

export async function requireAdmin(): Promise<void> {
  const session = await getServerSession(authOptions) as Session | null;
  
  if (!session?.user) {
    throw new Error('Unauthorized: No session found');
  }
  
  if (session.user.role !== 'ADMIN') {
    throw new Error('Forbidden: Admin access required');
  }
}

export async function requireManagerOrAdmin(): Promise<void> {
  const session = await getServerSession(authOptions) as Session | null;
  
  if (!session?.user) {
    throw new Error('Unauthorized: No session found');
  }
  
  if (!['ADMIN', 'MANAGER'].includes(session.user.role)) {
    throw new Error('Forbidden: Manager or Admin access required');
  }
}