import React from 'react';

export default function EditExpensePage() {
	return (
		<div className="p-8">
			<h1 className="text-2xl font-bold mb-4">Edit Expense</h1>
			{/* Add your expense edit form here */}
			<p>Fadlan ku dar form-ka edit-ka kharashka halkan.</p>
		</div>
	);
}
